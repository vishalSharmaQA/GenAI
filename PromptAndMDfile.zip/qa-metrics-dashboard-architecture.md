# QA Metrics Dashboard

**Technical Architecture & Build Guide**\
Version: 1.0\
Architecture Type: Full-Stack (React + Express + MongoDB)\
Deployment: Docker + Cloud-Agnostic Kubernetes

------------------------------------------------------------------------

# 1. Executive Summary

This document defines the complete architecture and build instructions
for a QA Metrics Dashboard that:

-   Aggregates metrics from:
    -   TCMS (Live API)
    -   Jira (Agile API) (Live API)
    -   MongoDB (Synced & normalized store)
-   Uses a Hybrid Model:
    -   Scheduled sync persists normalized metrics
    -   Dashboard primarily reads from MongoDB
    -   Live fetch available for validation
-   Supports:
    -   Sprint metrics (via Jira Agile API)
    -   Requirement coverage (via TCMS custom field storing Jira Story
        ID)
    -   Release-wise coverage
-   Authentication:
    -   Simple `.env` based Admin auth
    -   Dashboard open internally
    -   Configuration page admin-only
-   Deployment:
    -   Docker mandatory
    -   Cloud-agnostic Kubernetes compatible

------------------------------------------------------------------------

# 2. System Architecture

## High-Level Architecture

React Frontend → Express Backend → (TCMS API, Jira API)\
Backend → Sync Scheduler → MongoDB (Primary Read Store)

------------------------------------------------------------------------

# 3. Monorepo Structure

qa-metrics-dashboard/ backend/ frontend/ docker-compose.yml .env.example

------------------------------------------------------------------------

# 4. Environment Variables

Required:

TCMS_BASE_URL=\
TCMS_API_TOKEN=

JIRA_BASE_URL=\
JIRA_EMAIL=\
JIRA_API_TOKEN=\
JIRA_BOARD_ID=

MONGO_URI=

ADMIN_USERNAME=\
ADMIN_PASSWORD=

SYNC_CRON_EXPRESSION=0 \* \* \* \*

PORT=5000

------------------------------------------------------------------------

# 5. Data & Sync Model

## MongoDB Collections

### testCases

-   testCaseId
-   title
-   automationStatus
-   regressionTag
-   jiraStoryKey
-   sprintId
-   releaseId
-   createdAt
-   updatedAt

### sprints

-   sprintId
-   name
-   startDate
-   endDate
-   state

### stories

-   jiraStoryKey
-   sprintId
-   releaseId
-   status

### syncMetadata

-   lastSyncTime
-   status
-   duration

------------------------------------------------------------------------

# 6. Metric Endpoints

GET /metrics/automation-vs-manual\
GET /metrics/sprint-testcase-creation\
GET /metrics/sprint-automation-coverage\
GET /metrics/overall-automation-coverage\
GET /metrics/daily-automation-trend\
GET /metrics/testcase-growth\
GET /metrics/active-sprint-summary\
GET /metrics/regression-coverage\
GET /metrics/requirement-coverage\
GET /metrics/release-coverage

------------------------------------------------------------------------

# 7. Docker & Deployment

Backend and Frontend containerized via Docker.\
Kubernetes-ready with Deployment, Service, Ingress, Secret, ConfigMap.

------------------------------------------------------------------------

# 8. Validation & Assumptions

-   TCMS exposes automation status and Jira Story ID custom field.
-   Jira Agile API accessible with board ID.
-   Release information available in Jira metadata.
-   No additional data sources included.

------------------------------------------------------------------------

End of Document
