import { Router } from 'express'
import { JiraConfig, UserStory } from '../schemas'

interface JiraIssue {
  id: string
  key: string
  fields: {
    summary: string
    description?: string
  }
}

interface JiraAgileResponse {
  issues: JiraIssue[]
  maxResults: number
  startAt: number
  total: number
}

const router = Router()

// Connect to Jira and fetch user stories
router.post('/connect', async (req, res) => {
  try {
    console.log('Jira connect request received:', req.body)
    const config: JiraConfig = req.body

    // Validate config
    if (!config.baseUrl || !config.email || !config.apiKey) {
      console.log('Missing config:', { baseUrl: !!config.baseUrl, email: !!config.email, apiKey: !!config.apiKey })
      return res.status(400).json({ error: 'Missing required Jira configuration' })
    }

    // Extract domain from baseUrl
    const domain = config.baseUrl.replace('https://', '').replace('http://', '').split('/')[0]
    const jiraBaseUrl = `https://${domain}`
    console.log('Jira base URL:', jiraBaseUrl)

    // Create Basic Auth header
    const auth = Buffer.from(`${config.email}:${config.apiKey}`).toString('base64')
    console.log('Auth header created (first 20 chars):', auth.substring(0, 20) + '...')

    // Fetch user stories from board 2 using Jira Agile API
    const searchUrl = `${jiraBaseUrl}/rest/agile/1.0/board/2/issue`
    console.log('Jira API URL:', searchUrl)

    const response = await fetch(searchUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json',
      },
    })

    console.log('Jira API response status:', response.status)
    console.log('Jira API response ok:', response.ok)

    if (!response.ok) {
      const errorText = await response.text()
      console.error('Jira API error response:', errorText)
      return res.status(response.status).json({ 
        error: `Failed to fetch from Jira: ${response.status} ${response.statusText}` 
      })
    }

    const jiraData = await response.json() as JiraAgileResponse
    console.log('Jira API response received, issues count:', jiraData.issues?.length || 0)
    
    if (!jiraData.issues || !Array.isArray(jiraData.issues)) {
      console.error('Invalid Jira response structure:', jiraData)
      return res.status(500).json({ error: 'Invalid response from Jira API' })
    }

    // Transform Jira issues to UserStory format
    const userStories: UserStory[] = jiraData.issues.map((issue: any) => ({
      id: issue.id,
      key: issue.key,
      title: issue.fields?.summary || 'No title',
      description: issue.fields?.description || '',
      acceptanceCriteria: extractAcceptanceCriteria(issue.fields?.description || '')
    }))

    console.log('Transformed user stories count:', userStories.length)
    res.json(userStories)
    return
  } catch (error) {
    console.error('Jira connection error:', error)
    res.status(500).json({ error: 'Failed to connect to Jira' })
    return
  }
})

// Helper function to extract acceptance criteria from description
function extractAcceptanceCriteria(description: string): string {
  // Look for common patterns in acceptance criteria
  const patterns = [
    /acceptance criteria?:?\s*\n?(.*?)(?:\n\n|\n[A-Z]|$)/is,
    /(given.*?when.*?then.*?)/is,
    /scenarios?:?\s*\n?(.*?)(?:\n\n|\n[A-Z]|$)/is
  ]

  for (const pattern of patterns) {
    const match = description.match(pattern)
    if (match && match[1]) {
      return match[1].trim()
    }
  }

  // If no specific pattern found, return empty string
  return ''
}

export { router as jiraRouter }